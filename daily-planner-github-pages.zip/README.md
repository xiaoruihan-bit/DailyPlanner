# 小日程 · 每日计划

一个无后端、移动优先的每日计划表，支持日期管理、语音录入、完成进度、每日小结、数据备份和离线使用。

## 使用

直接用浏览器打开 `index.html` 即可使用核心功能。若要启用离线缓存和安装到主屏幕，请在本目录运行静态服务器，例如：

```bash
python -m http.server 8080
```

然后打开 `http://localhost:8080`。也可以将这几个文件部署到任何 HTTPS 静态托管服务。

## 发布到 GitHub Pages

1. 在 GitHub 新建一个公开仓库，例如 `daily-planner`。
2. 解压本项目文件，将 `index.html`、`styles.css`、`app.js`、`manifest.webmanifest`、`sw.js` 放到仓库根目录并提交。
3. 进入仓库的 **Settings → Pages**，在 **Build and deployment** 中选择 **Deploy from a branch**。
4. 分支选择 `main`，目录选择 `/ (root)`，点击保存。
5. 等待 GitHub Actions 完成后，访问：

```text
https://你的用户名.github.io/daily-planner/
```

首次打开后即可在手机或电脑浏览器中使用；手机浏览器还可以选择「添加到主屏幕」。GitHub Pages 提供 HTTPS，因此语音权限和离线缓存可以正常工作。

## 语音输入

在支持 Web Speech API 的 Chrome/Edge 等浏览器中点击「语音输入」，允许麦克风权限后说出计划。识别结果会先写入输入框，确认无误后再点击添加。部分浏览器的语音识别需要网络连接；不支持的浏览器会自动隐藏语音按钮，不影响手动输入。

## 数据与备份

计划和小结仅保存在当前浏览器的 `localStorage` 中，不会自动上传。使用右上角「导出数据」可生成 JSON 备份，在另一台设备点击「导入数据」恢复。清除浏览器站点数据会删除本机记录，请定期导出备份。
